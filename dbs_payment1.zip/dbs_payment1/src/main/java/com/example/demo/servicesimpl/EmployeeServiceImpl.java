package com.example.demo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repositories.EmployeeRepository;
import com.example.demo.services.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public Boolean add(Employee employee) {
		employeeRepository.save(employee);
		return true;
	}
	@Override
	public Boolean update(Employee employee) {
		employeeRepository.save(employee);
		return true;
	}
	@Override
	public Boolean save(Employee employee) {
		employeeRepository.save(employee);
		return true;
	}
	@Override
	public Boolean delete(Employee employee) {
		employeeRepository.delete(employee);
		return true;
	}
	
	public List<Employee> list(){
		return employeeRepository.findAll();
	}
}
