package com.example.demo.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.services.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:3000")
public class CustomerRestController {
	@Autowired
	private CustomerService customerService;
	@GetMapping("/")
	public List<Customer> listAllCustomer(){
		return customerService.list();
	}
	
	@PostMapping("/")
	public String saveBankObj(@RequestBody Customer customer) {
		if(customerService.add(customer)) {
			return "saved";
		}else {
			return "Failed";
		}
	}
	@PutMapping("/")
	public String updateBankObj(@RequestBody Customer customer) {
		if(customerService.update(customer)) {
			return "Updated";
		}else {
			return "Failed";
		}
	}
	@DeleteMapping("/")
	public String deleteBankObj(@RequestBody Customer customer) {
		if(customerService.delete(customer)){
			return "Deleted";
		}else {
			return "Failed";
		}
	}

}
