package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Transfertypes;

public interface TransfertypesService {
	public Boolean add(Transfertypes transferTypes);
	public Boolean update(Transfertypes transferTypes);
	public Boolean save(Transfertypes transferTypes);
	public Boolean delete(Transfertypes transferTypes);
	public List<Transfertypes>list();

}
