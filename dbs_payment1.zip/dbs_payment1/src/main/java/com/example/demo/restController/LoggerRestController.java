package com.example.demo.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Logger;
import com.example.demo.services.LoggerService;

@RestController
@RequestMapping("/logger")
@CrossOrigin(origins = "http://localhost:3000")
public class LoggerRestController {
	@Autowired
	private LoggerService loggerService;
	@GetMapping("/")
	public List<Logger> listAllLogger(){
		return loggerService.list();
	}
	
	@PostMapping("/")
	public String saveBankObj(@RequestBody Logger logger) {
		if(loggerService.add(logger)) {
			return "saved";
		}else {
			return "Failed";
		}
	}
	@PutMapping("/")
	public String updateBankObj(@RequestBody Logger logger) {
		if(loggerService.update(logger)) {
			return "Updated";
		}else {
			return "Failed";
		}
	}
	@DeleteMapping("/")
	public String deleteBankObj(@RequestBody Logger logger) {
		if(loggerService.delete(logger)){
			return "Deleted";
		}else {
			return "Failed";
		}
	}

}
