package com.example.demo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customeruser;
import com.example.demo.repositories.CustomeruserRepository;
import com.example.demo.services.CustomeruserService;

@Service
public class CustomeruserServiceImpl implements CustomeruserService {
	@Autowired
	private CustomeruserRepository customeruserRepository;
	
	@Override
	public Boolean add(Customeruser customeruser) {
		customeruserRepository.save(customeruser);
		return true;
	}
	@Override
	public Boolean update(Customeruser customeruser) {
		customeruserRepository.save(customeruser);
		return true;
	}
	@Override
	public Boolean delete(Customeruser customeruser) {
		customeruserRepository.delete(customeruser);
		return true;
	}
	@Override
	public Boolean save(Customeruser customeruser) {
		customeruserRepository.save(customeruser);
		return true;
	}
	public List<Customeruser>list(){
		return customeruserRepository.findAll();
	}
}
