package com.example.demo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Logger;
import com.example.demo.repositories.LoggerRepository;
import com.example.demo.services.LoggerService;

@Service
public class LoggerServiceImpl implements LoggerService {
	@Autowired
	private LoggerRepository loggerRepository;
	
	@Override
	public Boolean add(Logger logger) {
		loggerRepository.save(logger);
		return true;
	}
	@Override
	public Boolean update(Logger logger) {
		loggerRepository.save(logger);
		return true;
	}
	@Override
	public Boolean save(Logger logger) {
		loggerRepository.save(logger);
		return true;
	}
	@Override
	public Boolean delete(Logger logger) {
		loggerRepository.delete(logger);
		return true;
	}
	
	public List<Logger> list(){
		return loggerRepository.findAll();
	}
}
