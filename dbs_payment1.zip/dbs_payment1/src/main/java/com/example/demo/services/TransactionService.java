package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Transaction;

public interface TransactionService {
	public Boolean add(Transaction transaction);
	public Boolean update(Transaction transaction);
	public Boolean save(Transaction transaction);
	public Boolean delete(Transaction transaction);
	public List<Transaction> list();

}
