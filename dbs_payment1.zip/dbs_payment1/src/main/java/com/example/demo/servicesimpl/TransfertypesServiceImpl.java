package com.example.demo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Transfertypes;
import com.example.demo.repositories.TransfertypesRepository;
import com.example.demo.services.TransfertypesService;

@Service
public class TransfertypesServiceImpl implements TransfertypesService {
	@Autowired
	private TransfertypesRepository transfertypesRepository;
	
	@Override
	public Boolean add(Transfertypes transfertypes) {
		transfertypesRepository.save(transfertypes);
		return true;
	}
	@Override
	public Boolean update(Transfertypes transfertypes) {
		transfertypesRepository.save(transfertypes);
		return true;
	}
	@Override
	public Boolean save(Transfertypes transfertypes) {
		transfertypesRepository.save(transfertypes);
		return true;
	}
	@Override
	public Boolean delete(Transfertypes transfertypes) {
		transfertypesRepository.delete(transfertypes);
		return true;
	}
	
	public List<Transfertypes> list(){
		return transfertypesRepository.findAll();
	}
}
