package com.example.demo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Message;
import com.example.demo.repositories.MessageRepository;
import com.example.demo.services.MessageService;

@Service
public class MessageServiceImpl implements MessageService {
	@Autowired
	private MessageRepository messageRepository;
	
	@Override
	public Boolean add(Message message) {
		messageRepository.save(message);
		return true;
	}
	@Override
	public Boolean update(Message message) {
		messageRepository.save(message);
		return true;
	}
	@Override
	public Boolean save(Message message) {
		messageRepository.save(message);
		return true;
	}
	@Override
	public Boolean delete(Message message) {
		messageRepository.delete(message);
		return true;
	}
	
	public List<Message> list(){
		return messageRepository.findAll();
	}
}
