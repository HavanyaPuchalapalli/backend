package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Bank;

public interface BankService {
	public Boolean add(Bank bank);
	public Boolean update(Bank bank);
	public Boolean delete(Bank bank);
	public Boolean save(Bank bank);
	public List<Bank>list();
}
