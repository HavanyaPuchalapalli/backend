package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Logger;

public interface LoggerService {
	public Boolean add(Logger logger);
	public Boolean update(Logger logger);
	public Boolean delete(Logger logger);
	public Boolean save(Logger logger);
	public List<Logger>list();

}
