package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Customeruser;

public interface CustomeruserService {
	public Boolean add(Customeruser customerUser);
	public Boolean update(Customeruser customerUser);
	public Boolean delete(Customeruser customerUser);
	public Boolean save(Customeruser customerUser);
	public List<Customeruser>list();

}
