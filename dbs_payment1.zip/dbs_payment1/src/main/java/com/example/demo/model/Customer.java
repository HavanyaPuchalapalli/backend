package com.example.demo.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Customer_table")
public class Customer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3591791467935994808L;
	@Id
	private String customerId;
	@Column(length= 50,
			unique=true)
	private String accountHolderName;
	@Column(length = 1)
	private Boolean overDraftFlag;
	@Column(length = 10)
	private Double clearBalance;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public Boolean getOverDraftFlag() {
		return overDraftFlag;
	}
	public void setOverDraftFlag(Boolean overDraftFlag) {
		this.overDraftFlag = overDraftFlag;
	}
	public Double getClearBalance() {
		return clearBalance;
	}
	public void setClearBalance(Double clearBalance) {
		this.clearBalance = clearBalance;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		return Objects.hash(accountHolderName, clearBalance, customerId, overDraftFlag);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(accountHolderName, other.accountHolderName)
				&& Objects.equals(clearBalance, other.clearBalance) && Objects.equals(customerId, other.customerId)
				&& Objects.equals(overDraftFlag, other.overDraftFlag);
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", accountHolderName=" + accountHolderName + ", overDraftFlag="
				+ overDraftFlag + ", clearBalance=" + clearBalance + ", getCustomerId()=" + getCustomerId()
				+ ", getAccountHolderName()=" + getAccountHolderName() + ", getOverDraftFlag()=" + getOverDraftFlag()
				+ ", getClearBalance()=" + getClearBalance() + ", hashCode()=" + hashCode() + ", getClass()="
				+ getClass() + ", toString()=" + super.toString() + "]";
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}	
	
}
