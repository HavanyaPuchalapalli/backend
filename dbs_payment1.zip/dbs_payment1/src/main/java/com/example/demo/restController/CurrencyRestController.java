package com.example.demo.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Currency;
import com.example.demo.services.CurrencyService;

@RestController
@RequestMapping("/currency")
@CrossOrigin(origins = "http://localhost:3000")
public class CurrencyRestController {
	@Autowired
	private CurrencyService currencyService;
	@GetMapping("/")
	public List<Currency> listAllCurrency(){
		return currencyService.list();
	}
	
	@PostMapping("/")
	public String saveCurrencyObj(@RequestBody Currency currency) {
		if(currencyService.add(currency)) {
			return "saved";
		}else {
			return "Failed";
		}
	}
	@PutMapping("/")
	public String updateCurrencyObj(@RequestBody Currency currency) {
		if(currencyService.update(currency)) {
			return "Updated";
		}else {
			return "Failed";
		}
	}
	@DeleteMapping("/")
	public String deleteCurrencyObj(@RequestBody Currency currency) {
		if(currencyService.delete(currency)){
			return "Deleted";
		}else {
			return "Failed";
		}
	}

}
