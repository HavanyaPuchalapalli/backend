package com.example.demo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Transaction;
import com.example.demo.repositories.TransactionRepository;
import com.example.demo.services.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Override
	public Boolean add(Transaction transaction) {
		transactionRepository.save(transaction);
		return true;
	}
	@Override
	public Boolean update(Transaction transaction) {
		transactionRepository.save(transaction);
		return true;
	}
	@Override
	public Boolean save(Transaction transaction) {
		transactionRepository.save(transaction);
		return true;
	}
	@Override
	public Boolean delete(Transaction transaction) {
		transactionRepository.delete(transaction);
		return true;
	}
	
	public List<Transaction> list(){
		return transactionRepository.findAll();
	}
}
