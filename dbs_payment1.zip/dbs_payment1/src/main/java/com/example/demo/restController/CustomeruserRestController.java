package com.example.demo.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customeruser;
import com.example.demo.services.CustomeruserService;

@RestController
@RequestMapping("/customeruser")
@CrossOrigin(origins = "http://localhost:3000")
public class CustomeruserRestController {
	@Autowired
	private CustomeruserService customeruserService;
	@GetMapping("/")
	public List<Customeruser> listAllCustomeruser(){
		return customeruserService.list();
	}
	
	@PostMapping("/")
	public String saveBankObj(@RequestBody Customeruser customeruser) {
		if(customeruserService.add(customeruser)) {
			return "saved";
		}else {
			return "Failed";
		}
	}
	@PutMapping("/")
	public String updateBankObj(@RequestBody Customeruser customeruser) {
		if(customeruserService.update(customeruser)) {
			return "Updated";
		}else {
			return "Failed";
		}
	}
	@DeleteMapping("/")
	public String deleteBankObj(@RequestBody Customeruser customeruser) {
		if(customeruserService.delete(customeruser)){
			return "Deleted";
		}else {
			return "Failed";
		}
	}

}
