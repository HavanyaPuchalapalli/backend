package com.example.demo.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.services.EmployeeService;

@RestController
@RequestMapping("/employee")
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeRestController {
	@Autowired
	private EmployeeService employeeService;
	@GetMapping("/")
	public List<Employee> listAllEmployee(){
		return employeeService.list();
	}
	
	@PostMapping("/")
	public String saveBankObj(@RequestBody Employee employee) {
		if(employeeService.add(employee)) {
			return "saved";
		}else {
			return "Failed";
		}
	}
	@PutMapping("/")
	public String updateBankObj(@RequestBody Employee employee) {
		if(employeeService.update(employee)) {
			return "Updated";
		}else {
			return "Failed";
		}
	}
	@DeleteMapping("/")
	public String deleteBankObj(@RequestBody Employee employee) {
		if(employeeService.delete(employee)){
			return "Deleted";
		}else {
			return "Failed";
		}
	}

}
