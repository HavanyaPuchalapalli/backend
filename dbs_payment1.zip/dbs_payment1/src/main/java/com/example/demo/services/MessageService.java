package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Message;

public interface MessageService {
	public Boolean add(Message message);
	public Boolean update(Message logger);
	public Boolean delete(Message logger);
	public Boolean save(Message logger);
	public List<Message>list();
}